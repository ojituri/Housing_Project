from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from .models import Profile
from django.contrib.auth.models import User
from django.contrib import messages

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        role = request.POST.get('role','student')  # default student
        if form.is_valid():
            user = form.save()
            # create profile with role
            Profile.objects.create(user=user, role=role)
            messages.success(request, 'Registration successful. You can log in now.')
            return redirect('login')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = UserCreationForm()
    return render(request, 'accounts/register.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('dashboard')
    else:
        form = AuthenticationForm()
    return render(request, 'accounts/login.html', {'form': form})

@login_required
def dashboard(request):
    # redirect based on profile role
    try:
        role = request.user.profile.role
    except Profile.DoesNotExist:
        role = 'student'
    if role == 'student':
        return redirect('student_dashboard')
    elif role == 'staff':
        return redirect('staff_dashboard')
    elif role == 'admin':
        return redirect('admin_dashboard')
    return redirect('home')

def user_logout(request):
    logout(request)
    return redirect('home')
