from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import JobPost, Application
from django.contrib import messages
from django.contrib.auth.models import User

@login_required
def staff_dashboard(request):
    # simple staff dashboard
    jobs = JobPost.objects.filter(posted_by=request.user)
    return render(request, 'core/staff_dashboard.html', {'jobs': jobs})

@login_required
def student_dashboard(request):
    # student sees all open jobs
    jobs = JobPost.objects.all().order_by('-created_at')
    return render(request, 'core/student_dashboard.html', {'jobs': jobs})

@login_required
def create_job(request):
    if request.method == 'POST':
        title = request.POST.get('title', '').strip()
        company = request.POST.get('company', '').strip()
        description = request.POST.get('description', '').strip()
        location = request.POST.get('location', '').strip()
        deadline = request.POST.get('deadline', '').strip() or None

        if not title or not description:
            messages.error(request, 'Title and description are required.')
            return render(request, 'core/create_job.html', {'form_data': request.POST})

        job = JobPost.objects.create(
            posted_by=request.user,
            title=title,
            company=company,
            description=description,
            location=location,
            deadline=deadline or None
        )
        messages.success(request, 'Job posted successfully.')
        return redirect('staff_dashboard')

    return render(request, 'core/create_job.html')

@login_required
def apply_job(request, job_id):
    job = get_object_or_404(JobPost, pk=job_id)
    if request.method == 'POST':
        # create application if not exists
        app, created = Application.objects.get_or_create(job=job, student=request.user)
        if created:
            messages.success(request, 'Applied for the job successfully.')
        else:
            messages.info(request, 'You have already applied for this job.')
        return redirect('student_dashboard')

    return render(request, "core/apply_job.html", {"job": job})

@login_required
def view_applications(request, job_id):
    # staff can view applications for their job
    job = get_object_or_404(JobPost, pk=job_id, posted_by=request.user)
    applications = job.applications.all()
    return render(request, 'core/view_applications.html', {'job': job, 'applications': applications})

@login_required
def update_application_status(request, app_id):
    # staff updates status and remark
    app = get_object_or_404(Application, pk=app_id, job__posted_by=request.user)
    if request.method == 'POST':
        status = request.POST.get('status')
        remark = request.POST.get('remark', '').strip()
        if status in dict(Application.STATUS_CHOICES):
            app.status = status
            app.remark = remark
            app.save()
            messages.success(request, 'Application updated.')
        else:
            messages.error(request, 'Invalid status.')
        return redirect('view_applications', job_id=app.job.id)
    return render(request, 'core/update_application.html', {'app': app})



def home(request):
    # public home page shows recent jobs
    jobs = JobPost.objects.all().order_by('-created_at')[:10]
    return render(request, 'core/student_dashboard.html', {'jobs': jobs})
