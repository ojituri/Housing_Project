from django.urls import path
from . import views

urlpatterns = [
    path('staff-dashboard/', views.staff_dashboard, name='staff_dashboard'),
    path('student-dashboard/', views.student_dashboard, name='student_dashboard'),
    path('job/create/', views.create_job, name='create_job'),
    path('job/<int:job_id>/apply/', views.apply_job, name='apply_job'),
    path('job/<int:job_id>/applications/', views.view_applications, name='view_applications'),
    path('application/<int:app_id>/update/', views.update_application_status, name='update_application'),
]
