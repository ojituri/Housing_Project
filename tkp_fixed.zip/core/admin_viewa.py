from django.contrib.auth.decorators import user_passes_test
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.contrib import messages

def is_admin(user):
    return user.is_superuser or user.profile.role == 'admin'

@user_passes_test(is_admin)
def create_staff(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST.get('email','')
        password = request.POST['password']
        user = User.objects.create_user(username=username, email=email, password=password)
        user.profile.role = 'staff'
        user.profile.save()
        messages.success(request, 'Staff account created.')
        return redirect('admin_dashboard')
    return render(request, 'core/create_staff.html')
