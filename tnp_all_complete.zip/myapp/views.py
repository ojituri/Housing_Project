from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from .forms import UserRegisterForm, StudentProfileForm, LoginForm, ApplicationForm, ProblemForm
from .models import StudentProfile, Job, Application, Training, ProblemReport
from django.contrib.auth.models import User

def home(request):
    # Landing page (home.html)
    jobs = Job.objects.order_by('-created_at')[:6]
    return render(request, 'myapp/home.html', {'jobs': jobs})

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        profile_form = StudentProfileForm(request.POST)
        if form.is_valid() and profile_form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            profile = profile_form.save(commit=False)
            profile.user = user
            profile.save()
            messages.success(request, 'Account created. Please login.')
            return redirect('login')
    else:
        form = UserRegisterForm()
        profile_form = StudentProfileForm()
    return render(request, 'myapp/register.html', {'form': form, 'profile_form': profile_form})

def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user_type = form.cleaned_data['user_type']
            user = authenticate(request, username=username, password=password)
            if user:
                if user_type == 'admin' and user.is_staff:
                    login(request, user)
                    return redirect('admin_dashboard')
                elif user_type == 'student' and not user.is_staff:
                    login(request, user)
                    return redirect('student_dashboard')
                else:
                    messages.error(request, 'User type mismatch or insufficient privileges.')
            else:
                messages.error(request, 'Invalid credentials.')
    else:
        form = LoginForm()
    return render(request, 'myapp/login.html', {'form': form})

def user_logout(request):
    logout(request)
    return redirect('home')

@login_required
def student_dashboard(request):
    # ensure student profile exists
    profile, _ = StudentProfile.objects.get_or_create(user=request.user)
    jobs = Job.objects.order_by('-created_at')
    applications = Application.objects.filter(student=profile).order_by('-applied_at')
    trainings = Training.objects.all().order_by('-start_date')[:5]
    return render(request, 'myapp/student_dashboard.html', {
        'profile': profile,
        'jobs': jobs,
        'applications': applications,
        'trainings': trainings,
    })

def is_admin_user(u):
    return u.is_authenticated and u.is_staff

@user_passes_test(is_admin_user, login_url='login')
def admin_dashboard(request):
    total_students = StudentProfile.objects.count()
    total_jobs = Job.objects.count()
    total_applications = Application.objects.count()
    trainings = Training.objects.order_by('-created_at')[:5]
    return render(request, 'myapp/admin_dashboard.html', {
        'total_students': total_students,
        'total_jobs': total_jobs,
        'total_applications': total_applications,
        'trainings': trainings,
    })

@login_required
def submit_problem(request):
    profile = get_object_or_404(StudentProfile, user=request.user)
    if request.method == 'POST':
        form = ProblemForm(request.POST)
        if form.is_valid():
            pr = form.save(commit=False)
            pr.student = profile
            pr.save()
            messages.success(request, 'Problem submitted.')
            return redirect('student_dashboard')
    else:
        form = ProblemForm()
    return render(request, 'myapp/problem.html', {'form': form})

@login_required
def apply_job(request, job_id):
    profile = get_object_or_404(StudentProfile, user=request.user)
    job = get_object_or_404(Job, id=job_id)
    if request.method == 'POST':
        form = ApplicationForm(request.POST, request.FILES)
        if form.is_valid():
            app = form.save(commit=False)
            app.student = profile
            app.job = job
            app.save()
            messages.success(request, 'Application submitted.')
            return redirect('student_dashboard')
    else:
        form = ApplicationForm()
    return render(request, 'myapp/apply_job.html', {'form': form, 'job': job})



from django.core.mail import send_mail
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.contrib.auth.tokens import default_token_generator
from django.template.loader import render_to_string
from django.conf import settings
from django.urls import reverse

def send_verification_email(request, user):
    uid = urlsafe_base64_encode(force_bytes(user.pk))
    token = default_token_generator.make_token(user)
    verify_link = f"{settings.SITE_URL}{reverse('verify_email', args=[uid, token])}"
    subject = "Verify your email for T&P Portal"
    message = render_to_string('myapp/email_verify.txt', {'user': user, 'verify_link': verify_link})
    send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [user.email], fail_silently=False)

def verify_email(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except Exception as e:
        user = None
    if user and default_token_generator.check_token(user, token):
        user.is_active = True
        user.save()
        login(request, user)
        return render(request, 'myapp/verify_success.html', {})
    else:
        return render(request, 'myapp/verify_failed.html', {})

@login_required
def profile_edit(request):
    profile, _ = StudentProfile.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        form = ProfileEditForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated.')
            return redirect('student_dashboard')
    else:
        form = ProfileEditForm(instance=profile)
    return render(request, 'myapp/profile_edit.html', {'form': form})
