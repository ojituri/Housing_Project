from django import forms
from django.contrib.auth.models import User
from .models import StudentProfile, Application, ProblemReport

class UserRegisterForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput, min_length=6)
    confirm_password = forms.CharField(widget=forms.PasswordInput, min_length=6)

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password']

    def clean(self):
        cleaned = super().clean()
        pw = cleaned.get('password')
        cpw = cleaned.get('confirm_password')
        if pw and cpw and pw != cpw:
            raise forms.ValidationError("Passwords do not match.")
        return cleaned

class StudentProfileForm(forms.ModelForm):
    class Meta:
        model = StudentProfile
        fields = ['branch', 'year', 'cgpa', 'phone']

class LoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)
    user_type = forms.ChoiceField(choices=[('student','Student'),('admin','Administrator')])

class ApplicationForm(forms.ModelForm):
    class Meta:
        model = Application
        fields = ['cover_letter', 'resume']

class ProblemForm(forms.ModelForm):
    class Meta:
        model = ProblemReport
        fields = ['title', 'description']


class ProfileEditForm(forms.ModelForm):
    class Meta:
        model = StudentProfile
        fields = ['branch', 'year', 'cgpa', 'phone']
