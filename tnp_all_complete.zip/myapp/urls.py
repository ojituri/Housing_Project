from django.urls import path
from . import views

urlpatterns = [
    path('profile/edit/', views.profile_edit, name='profile_edit',
    path('verify-email/<uidb64>/<token>/', views.verify_email, name='verify_email',
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
    path('student/dashboard/', views.student_dashboard, name='student_dashboard'),
    path('admin/dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('student/problem/', views.submit_problem, name='submit_problem'),
    path('job/<int:job_id>/apply/', views.apply_job, name='apply_job'),
]
