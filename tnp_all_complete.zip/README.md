# T&P Portal (Django)

This is a Training & Placement (T&P) Portal demo built with Django and Tailwind CSS.

## What I changed
- Converted the front-end templates to Django templates.
- Added a `base.html` for shared header/footer.
- Updated login/register templates to use Django forms with Tailwind styling.
- Fixed static paths and URL usage.
- Added `requirements.txt`, `Procfile`, and a README.

## Run locally

1. Create and activate venv:
   - Windows: `env\Scripts\activate`
   - macOS/Linux: `source env/bin/activate`

2. Install dependencies:
```
pip install -r requirements.txt
```

3. Run migrations:
```
python manage.py makemigrations
python manage.py migrate
```

4. Create superuser:
```
python manage.py createsuperuser
```

5. Run server:
```
python manage.py runserver
```

Open http://127.0.0.1:8000/

## Notes
- Static assets are located in `myapp/static/assets/`. Ensure files like `assets/css/styles.css` and images exist.
- For production, set `DEBUG=False`, configure `ALLOWED_HOSTS`, and use a proper static/media hosting solution.
